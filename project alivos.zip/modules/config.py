from rich.console import Console
from urllib.parse import urlparse
from rich.console import Console


def zersucc(url, message):
    return Console().print(f"[blink bold white underline on green]-- {url} --[/blink bold white underline on green][bold green] {message} [/bold green]")


def zerfail(url, message):
    return Console().print(f"[blink bold white underline on red]-- {url} --[/blink bold white underline on red][bold red] {message} [/bold red]")


def zerinfo(url, message):
    return Console().print(f"[blink bold white underline on blue]-- {url} --[/blink bold white underline on blue][bold blue] {message} [/bold blue]")


def zerwarn(url, message):
    return Console().print(f"[blink bold white underline on yellow]-- {url} --[/blink bold white underline on yellow][bold yellow] {message} [/bold yellow]")


def write_file(filename, content):
    with open(filename, "w") as f:
        f.write(content)
        f.close()


def format_url(url):
    parse_url = urlparse(url)
    if parse_url.scheme:
        target_url = "{}://{}".format(parse_url.scheme if parse_url.scheme in [
                                      "http", "https"] else "http", parse_url.netloc)
    else:
        target_url = "http://{}".format(url)
    return target_url


def banner(text):
    return Console().print(f"[bold red] {text} [/bold red]")
